import pandas as pd
import os
from faker import Faker
import random


def get_faker_data(num=100):
    # 初始化Faker，用于生成随机数据
    fake = Faker()

    # 预定义一些地标类型和形容词，以增加数据的多样性
    landmark_types = ['建筑', '纪念碑', '自然景观', '历史遗迹', '现代建筑', '宗教场所', '博物馆', '公园', '雕塑', '桥梁']
    adjectives = ['宏伟的', '美丽的', '壮观的', '古老的', '现代的', '独特的', '令人印象深刻的', '著名的', '迷人的', '神秘的']

    # 生成100条数据
    data = []
    for i in range(num):
        country = fake.country()
        city = fake.city()
        landmark_type = random.choice(landmark_types)
        adjective = random.choice(adjectives)
        year = random.randint(-3000, 2023)  # 使用-3000到2023年的随机年份
        
        title = f"{country}的{adjective}{landmark_type}"
        content = f"{title}位于{city}，是{country}最著名的{landmark_type}之一。它建于公元{year}年（{'公元前' if year < 0 else '公元'}）。这个{adjective.replace('的', '')}{landmark_type}以其{random.choice(['独特的设计', '历史意义', '文化价值', '自然美景'])}而闻名。每年都有来自世界各地的游客前来参观。"
        
        data.append({"title": title, "content": content})
    return data


# 创建DataFrame
data = get_faker_data()
df = pd.DataFrame(data)

# 创建一个临时目录来存储文本文件
if not os.path.exists('temp_docs'):
    os.mkdir('temp_docs')

# 将每个文档保存为单独的文本文件
for i, row in df.iterrows():
    with open(f'temp_docs/doc_{i}.txt', 'w', encoding='utf-8') as f:
        f.write(f"{row['title']}\n\n{row['content']}")

print("已生成100条数据并保存到temp_docs目录。")

# 打印前几条数据作为示例
print(df.head())